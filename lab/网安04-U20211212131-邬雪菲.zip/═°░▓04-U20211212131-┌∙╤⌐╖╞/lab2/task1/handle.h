#ifndef HANDLE_H
#define HANDLE_H

#include "http-tree.h"
#include "sql_lite3/sqlhelper.h"

void Handle_main (int fd, Http_t tree);

#endif
